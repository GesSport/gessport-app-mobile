package com.example.gesport.ui.backend.ges_user

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.gesport.models.User
import com.example.gesport.repository.UserRepository
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch

class GesUserViewModel(
    private val userRepository: UserRepository
) : ViewModel() {

    private var _allUsers by mutableStateOf<List<User>>(emptyList())

    private var _users by mutableStateOf<List<User>>(emptyList())
    val users: List<User> get() = _users

    private var _selectedRole by mutableStateOf<String?>(null)
    val selectedRole: String? get() = _selectedRole

    private var _searchQuery by mutableStateOf("")
    val searchQuery: String get() = _searchQuery

    private var _isLoading by mutableStateOf(false)
    val isLoading: Boolean get() = _isLoading

    private var _errorMessage by mutableStateOf<String?>(null)
    val errorMessage: String? get() = _errorMessage

    private var usersJob: Job? = null

    init {
        observeUsers(role = null)
    }

    private fun observeUsers(role: String?) {
        usersJob?.cancel()

        usersJob = viewModelScope.launch {
            _isLoading = true
            _errorMessage = null

            try {
                val flow = if (role == null) {
                    userRepository.getAllUsers()
                } else {
                    userRepository.getUsersByRole(role)
                }

                flow.collectLatest { list ->
                    _allUsers = list
                    applyFilters()
                    _isLoading = false
                }
            } catch (e: CancellationException) {
                _isLoading = false
                throw e
            } catch (e: Exception) {
                _errorMessage = e.message ?: "Error al cargar los usuarios"
                _allUsers = emptyList()
                _users = emptyList()
                _isLoading = false
            }
        }
    }

    private fun applyFilters() {
        var filtered = _allUsers

        val q = _searchQuery.trim().lowercase()
        if (q.isNotEmpty()) {
            filtered = filtered.filter { user ->
                user.nombre.lowercase().contains(q) ||
                        user.email.lowercase().contains(q)
            }
        }

        _users = filtered
    }

    fun onRoleSelected(rol: String?) {
        _selectedRole = rol
        observeUsers(role = rol)
    }

    fun onSearchQueryChange(newQuery: String) {
        _searchQuery = newQuery
        applyFilters()
    }

    fun addUser(user: User) {
        viewModelScope.launch {
            try {
                _errorMessage = null
                userRepository.addUser(user)
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                _errorMessage = e.message ?: "No se ha podido crear el usuario"
            }
        }
    }

    fun updateUser(user: User) {
        viewModelScope.launch {
            try {
                _errorMessage = null
                val rows = userRepository.updateUser(user)
                if (rows <= 0) {
                    _errorMessage = "Este usuario ya no existe"
                }
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                _errorMessage = e.message ?: "No se ha podido actualizar el usuario"
            }
        }
    }

    fun deleteUser(id: Int) {
        viewModelScope.launch {
            try {
                _errorMessage = null
                val ok = userRepository.deleteUser(id)
                if (!ok) {
                    _errorMessage = "No se ha podido borrar el usuario"
                }
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                _errorMessage = e.message ?: "No se ha podido borrar el usuario"
            }
        }
    }

    fun loadUserById(id: Int, onResult: (User?) -> Unit) {
        viewModelScope.launch {
            try {
                val user = userRepository.getUserById(id)
                onResult(user)
            } catch (e: CancellationException) {
                throw e
            } catch (_: Exception) {
                onResult(null)
            }
        }
    }
}