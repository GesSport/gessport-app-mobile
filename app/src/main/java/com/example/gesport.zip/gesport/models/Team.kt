package com.example.gesport.models

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(
    tableName = "equipos"
)
data class Team(
    @PrimaryKey(autoGenerate = true)
    val id: Int = 0,
    val nombre: String,
    val categoria: String,
    val entrenadorId: Int? = null
)